<template>
  <div>
    <p class="headline">
      Something wrong happend
    </p>
    <p>
      Sorry, we got an unknown error.
    </p>
  </div>
</template>
